<?php $__env->startSection('page-css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main id="content" class="site-content">

        <article id="frontPage" class="content-area">
            <section class="hero">
                <div class="hero_container">
                    <p id="hero_text1">
                        <span class="hero_text1Element" data-id="0"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">C</span>
                        <span class="hero_text1Element" data-id="1"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">H</span>
                        <span class="hero_text1Element" data-id="2"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">A</span>
                        <span class="hero_text1Element" data-id="3"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">L</span>
                        <span class="hero_text1Element" data-id="4"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">L</span>
                        <span class="hero_text1Element" data-id="5"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">E</span>
                        <span class="hero_text1Element" data-id="6"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">N</span>
                        <span class="hero_text1Element" data-id="7"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">G</span>
                        <span class="hero_text1Element" data-id="8"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">E</span>
                    </p>
                    <svg id="handwritingmask" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 790 450">
                        <image xmlns:xlink="http://www.w3.org/1999/xlink"
                               xlink:href="<?php echo e(asset('img/everything.png')); ?>"
                               mask="url(#clipmask)" id="handwritingmask_img" width="790" height="450"
                               class="active"></image>
                        <mask id="clipmask" maskUnits="">
                            <path class="cls-1" d="M27,199.05l77-52.83s119-63,143.84-59.82"
                                  transform="translate(10 5.99)"
                                  style="stroke-dasharray: 250, 252; stroke-dashoffset: 0;"></path>
                            <path class="cls-1" d="M110.36,126.49s13.54,14.64-22.73,251.4" transform="translate(4 6.99)"
                                  style="stroke-dasharray: 254, 256; stroke-dashoffset: 0;"></path>
                            <path class="cls-1" d="M75.13,280.35L175.9,218.99"
                                  style="stroke-dasharray: 118, 120; stroke-dashoffset: 0;"></path>
                            <path class="cls-1" d="M0,424S115.22,318.63,239.54,309.31" transform="translate(9 11.99)"
                                  style="stroke-dasharray: 270, 272; stroke-dashoffset: 0;"></path>
                            <path class="cls-1" d="M202.59,191.89s8.16,42,11.65,117.42c0,0,6.41-143,68.15-161.1"
                                  transform="translate(10 6.99)"
                                  style="stroke-dasharray: 302, 304; stroke-dashoffset: 0;"></path>
                            <path class="cls-1"
                                  d="M265.5,232.67s38.45-21,16.89-48.93c0,0-42.52,39.61-14,90.87,0,0,29.13-10.49,36.12-40.19"
                                  transform="translate(8 10.99)"
                                  style="stroke-dasharray: 216, 218; stroke-dashoffset: 0;"></path>
                            <path class="cls-1"
                                  d="M304.53,183.74l11.07-5.24,2.91,16.31-14,74.55S334.24,168,366.85,152.87"
                                  transform="translate(10 6.99)"
                                  style="stroke-dasharray: 240, 242; stroke-dashoffset: 0;"></path>
                            <path class="cls-1"
                                  d="M366.85,180s-23.65,54.12-5.54,60.64,48.3-87.81,48.3-87.81-63.62,216.59-42.76,240"
                                  transform="translate(14 10.99)"
                                  style="stroke-dasharray: 416, 418; stroke-dashoffset: 0;"></path>
                            <path class="cls-1" d="M332.63,152.87l121.5-91.32s150.18-95.84,193.2-42.26"
                                  transform="translate(14 8.99)"
                                  style="stroke-dasharray: 363, 365; stroke-dashoffset: 0;"></path>
                            <path class="cls-1" d="M466.21,26.84s-54.34,168.29-25.66,198.48c0,0,26.9-1.12,46.52-45.58"
                                  transform="translate(15 12.99)"
                                  style="stroke-dasharray: 273, 275; stroke-dashoffset: 0;"></path>
                            <path class="cls-1"
                                  d="M521.3,35.89s-47.09,167.28-30.23,223.88c0,0,4.57-106.83,43.06-133.28v11.28S508.47,217,522.81,221.54,550,179.28,550,179.28"
                                  transform="translate(17 6.99)"
                                  style="stroke-dasharray: 524, 526; stroke-dashoffset: 0;"></path>
                            <path class="cls-1" d="M601.2,75.54L584.88,95.27"
                                  style="stroke-dasharray: 26, 28; stroke-dashoffset: 0;"></path>
                            <path class="cls-1" d="M574.88,122.68s-24.15,68.68,0,70.94c0,0,21.13-22.9,24.9-45.41"
                                  transform="translate(17 9.99)"
                                  style="stroke-dasharray: 130, 132; stroke-dashoffset: 0;"></path>
                            <path class="cls-1"
                                  d="M620.91,98.53s-30.18,62.93-8.3,100.52c0,0,22.64-91.46,49.81-109.57v14.33s-36.22,66.41-15.09,69.43,30.94-30.58,30.94-30.58"
                                  transform="translate(20 6.99)"
                                  style="stroke-dasharray: 365, 367; stroke-dashoffset: 0;"></path>
                            <path class="cls-1"
                                  d="M716.76,86.28S673,128,688.83,158.15s31.7-63.39,31.7-63.39,16.74,92.31-37.15,187.4l-8.88-22.39s20.37-111.43,93.57-152.94"
                                  transform="translate(23 10.99)"
                                  style="stroke-dasharray: 570, 572; stroke-dashoffset: 0;"></path>
                        </mask>
                    </svg>
                    <p id="hero_text2">
                        <span class="hero_text2Element" data-id="0"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">F</span>
                        <span class="hero_text2Element" data-id="1"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">O</span>
                        <span class="hero_text2Element" data-id="2"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">R&nbsp;</span>
                        <span class="hero_text2Element" data-id="3"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">Y</span>
                        <span class="hero_text2Element" data-id="4"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">O</span>
                        <span class="hero_text2Element" data-id="5"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">U</span>
                        <span class="hero_text2Element" data-id="6"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">R</span><br>
                        <span class="hero_text2Element" data-id="7"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">F</span>
                        <span class="hero_text2Element" data-id="8"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">U</span>
                        <span class="hero_text2Element" data-id="9"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">T</span>
                        <span class="hero_text2Element" data-id="10"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">U</span>
                        <span class="hero_text2Element" data-id="11"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">R</span>
                        <span class="hero_text2Element" data-id="12"
                              style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">E</span>
                    </p>
                </div>
            </section>

            <section class="about">
                <section class="company">
                    <div class="company_container">
                        <img class="company_bg" src="<?php echo e(asset('img/company_bg.jpg')); ?>"
                             alt="company">
                        <div class="company_contentWrapper">
                            <div class="animationTargetWrapper">
                                <h2 class="company_title scrollAnimation"
                                    style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">COMPANY</h2>
                                <p class="company_txt scrollAnimation"
                                   style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                                    私たちFUTURESはクライアントとユーザーの間に存在しております。<br>
                                    常にユーザーのための未来を考え、より良いサービス、新たな価値を提供し続けます<br class="pc">
                                    皆様のご期待に添えますよう全力で臨みます。
                                </p>
                                <a href="<?php echo e(route('company')); ?>" class="futuresBtn scrollAnimation"
                                   style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">VIEW MORE</a>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="service">
                    <div class="service_container">
                        <img class="service_img" src="<?php echo e(asset('img/service.jpg')); ?>"
                             alt="service">
                        <div class="service_contentWrapper">
                            <div class="animationTargetWrapper">
                                <h2 class="service_title scrollAnimation"
                                    style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">SERVICE</h2>
                                <p class="service_txt scrollAnimation"
                                   style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                                    Webデザイン、オフィスソリューション、店舗コンサルティングを通し<br class="pc">
                                    全てのユーザー・クライアントが満足できるサービスの提供を目指しております。
                                </p>
                                <a href="<?php echo e(route('service')); ?>" class="service_linkBtn scrollAnimation"
                                   style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">VIEW MORE</a>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="recruit">
                    <div class="recruit_container">
                        <div class="recruit_contentWrapper">
                            <div class="animationTargetWrapper">
                                <h2 class="recruit_title scrollAnimation"
                                    style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">RECRUIT</h2>
                                <p class="recruit_txt scrollAnimation"
                                   style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">
                                    ”Challenge Everithing for Your future”<br>
                                    という理念のもと、自分の成長にこだわり、<br class="pc">
                                    自ら能動的かつ迅速かつ柔軟に動き、結果を残す人材を求めています。
                                </p>
                                <a href="<?php echo e(route('recruit')); ?>" class="recruit_linkBtn scrollAnimation"
                                   style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">VIEW MORE</a>
                            </div>
                        </div>
                        <img src="<?php echo e(asset('img/recruit.png')); ?>" alt="recruit"
                             class="recruit_img">
                    </div>
                </section>
            </section>
























        </article><!-- #frontPage -->


    </main><!-- #content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\_WORKSPACE\Web\NEXTITM\NextITM\resources\views/home.blade.php ENDPATH**/ ?>