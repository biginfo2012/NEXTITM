<footer class="site-footer">
    <div class="footer_line">
        <span></span>
    </div>
    <div id="pageTop">PAGE TOP</div>

    <div class="footer_content">
        <div class="menu-footer-container">
            <ul id="menu-footer" class="footerMenu">
                <li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-5">
                    <a href="<?php echo e(url('/')); ?>">TOP</a></li>
                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a
                        href="<?php echo e(route('company')); ?>">COMPANY</a></li>
                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a
                        href="<?php echo e(route('service')); ?>">SERVICE</a></li>
                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19"><a
                        href="<?php echo e(route('recruit')); ?>">RECRUIT</a></li>
                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-17"><a
                        href="<?php echo e(route('contact')); ?>">CONTACT</a></li>
            </ul>
        </div>
        <div class="footer_logo">
            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="futures-logo">
            <p> ©️ NEXT ITM Inc. All Rights Reserved</p>
        </div>
    </div>
</footer>
<?php /**PATH D:\_WORKSPACE\Web\NEXTITM\NextITM\resources\views/layout/footer.blade.php ENDPATH**/ ?>